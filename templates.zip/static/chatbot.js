

$("#bot3b").hide();
$("#bot3b2").hide();
$("#user3b").hide();
$("#bot2b").hide();
$("#bot2c").hide();
$("#botmusic").hide();
$("#user2b").hide();
$("#user2c").hide();
$("#bot4a").hide();
$("#botaboutus").hide();
$("#botcommunity").hide();
$("#bottest").hide();
$("#botappointment").hide();

$(document).ready(function(){
   
    var user1ans2 = document.querySelector(".user1ans2");
    user1ans2.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botaboutus").hide();
            $("#botcommunity").hide();
            $("#bottest").hide();
            $("#botappointment").hide();
            $("#bot2b").show();
            $("#user2b").show();
        },500);
    })

        var helpline = document.querySelector(".helpline");
        helpline.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b2").hide();
            $("#user3b").hide();
           
            $("#bot2c").hide();
            $("#botmusic").hide();
            
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botaboutus").hide();
            $("#botcommunity").hide();
            $("#bottest").hide();
            $("#botappointment").hide();
            $("#bot3b").show();
        },500);
       
    })  
    var suggestions = document.querySelector(".suggestions");
    suggestions.addEventListener("click",function(){
    setTimeout(function(){
       
        $("#user3b").hide();
        
        $("#bot2c").hide();
        $("#botmusic").hide();
       
        $("#user2c").hide();
        $("#bot4a").hide();
        $("#botaboutus").hide();
        $("#botcommunity").hide();
        $("#bottest").hide();
        $("#botappointment").hide();
        $("#bot3b2").show();
    },500);
   
    })  

})

$(document).ready(function(){
   
        var user1ans7 = document.querySelector(".user1ans7");
        user1ans7.addEventListener("click",function(){
            setTimeout(function(){
                $("#bot3b").hide();
                $("#bot3b2").hide();
                $("#user3b").hide();
                $("#bot2b").hide();
                $("#botmusic").hide();
                $("#user2b").hide();
                $("#user2c").hide();
                $("#bot4a").hide();
                $("#botaboutus").hide();
                $("#botcommunity").hide();
                $("#bottest").hide();
                $("#botappointment").hide();
                $("#bot2c").show();

            },500);
        })
    
           
})  

$(document).ready(function(){
   
    var user1ans1 = document.querySelector(".user1ans1");
    user1ans1.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#botaboutus").hide();
            $("#botcommunity").hide();
            $("#bottest").hide();
            $("#botappointment").hide();
            $("#bot4a").show();

        },500);
    })

       
})  

$(document).ready(function(){
   
            var user1ans8 = document.querySelector(".user1ans8");
            user1ans8.addEventListener("click",function(){
                setTimeout(function(){
                    $("#bot3b").hide();
                    $("#bot3b2").hide();
                    $("#user3b").hide();
                    $("#bot2b").hide();
                    $("#bot2c").hide();
                    $("#user2b").hide();
                    $("#user2c").hide();
                    $("#bot4a").hide();
                    $("#botaboutus").hide();
                    $("#botcommunity").hide();
                    $("#bottest").hide();
                    $("#botappointment").hide();
                    $("#botmusic").show();
    
                },500);
            })
        
               
})  

// 1
$(document).ready(function(){
   
    var user1ans3 = document.querySelector(".user1ans3");
    user1ans3.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botaboutus").hide();
            $("#botcommunity").hide();
            $("#botappointment").hide();
            $("#bottest").show();

        },500);
    })

       
})  
// 2

$(document).ready(function(){
   
    var user1ans4 = document.querySelector(".user1ans4");
    user1ans4.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botaboutus").hide();
            $("#botcommunity").hide();
            $("#bottest").hide();
            $("#botappointment").show();

        },500);
    })

       
})  
// 3

$(document).ready(function(){
   
    var user1ans5  = document.querySelector(".user1ans5");
    user1ans5.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botaboutus").hide();
            $("#bottest").hide();
            $("#botappointment").hide();
            $("#botcommunity").show();

        },500);
    })

       
})  
// 4

$(document).ready(function(){
   
    var user1ans6 = document.querySelector(".user1ans6");
    user1ans6.addEventListener("click",function(){
        setTimeout(function(){
            $("#bot3b").hide();
            $("#bot3b2").hide();
            $("#user3b").hide();
            $("#bot2b").hide();
            $("#bot2c").hide();
            $("#botmusic").hide();
            $("#user2b").hide();
            $("#user2c").hide();
            $("#bot4a").hide();
            $("#botcommunity").hide();
            $("#bottest").hide();
            $("#botappointment").hide();
            $("#botaboutus").show();

        },500);
    })

       
})  
